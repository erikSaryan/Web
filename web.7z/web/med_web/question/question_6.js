function name_mask() {
    $(".phone").mask("+374(99) 99-99-99");
}

$( document ).ready(function() {
    name_mask()
});
